<?php
$config['db']['host'] = 'localhost';
$config['db']['name'] = 'jobclass';
$config['db']['user'] = 'root';
$config['db']['pass'] = '';
$config['db']['pre'] = 'job_';

$config['version'] = '4.3';
?>